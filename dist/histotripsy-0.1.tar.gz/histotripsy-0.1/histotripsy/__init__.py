# Useful functions for common image/data processing methods performed 
# in the Image-Guided Ultrasound Therapy (aka Histotripsy) lab at the
# University of Michigan Department of Biomedical Engineering
#
# __init__.py file
#
#
# Curated by Jonathan J. Macoskey
# https://github.com/macoskey
#
# First created: 12.1.17

def firstFunction():
	print "Test"
